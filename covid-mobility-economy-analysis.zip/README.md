# Impact of COVID-19 on Global Mobility and Economic Indicators

This project explores how the COVID-19 pandemic affected global mobility patterns and key economic indicators across countries using real-world data.

## 📈 Objectives
- Analyze Google mobility data
- Correlate with economic indicators like GDP, unemployment, etc.
- Generate meaningful insights and visualizations

## 📁 Project Structure

```
data/             → Raw and processed data files  
notebooks/        → Jupyter notebooks for exploration and analysis  
scripts/          → Python scripts for data wrangling and preprocessing  
visualizations/   → Saved charts and plots  
```

## 📊 Datasets
- [Google Mobility Reports](https://www.google.com/covid19/mobility/)
- [World Bank Indicators](https://data.worldbank.org/)
- [Our World in Data](https://ourworldindata.org/coronavirus)

## 🛠 Tech Stack
- Python (Pandas, Matplotlib, Seaborn)
- Jupyter Notebook
- Git / GitHub

## 🚀 Getting Started

```bash
git clone https://github.com/ANIKETDESHMUKH12699/covid-mobility-economy-analysis.git
cd covid-mobility-economy-analysis
pip install -r requirements.txt
```

## 📌 To-Do
- [ ] Download and clean datasets
- [ ] Perform EDA
- [ ] Visualize trends and patterns
- [ ] Correlate mobility with economic metrics
- [ ] Deploy dashboard (optional)
